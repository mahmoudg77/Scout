<?
namespace App\Controllers;
class GroupCategory extends BaseController
{
    protected  $model="App\Models\Auth\GroupCategory";
    protected  $authRequired=true;


}

?>
