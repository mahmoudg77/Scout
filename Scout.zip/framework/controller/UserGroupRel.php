<?
namespace App\Controllers;
class UserGroupRel extends BaseController
{
    protected  $model="App\Models\Auth\UserGroupRel";
    protected  $authRequired=true;


}

?>
