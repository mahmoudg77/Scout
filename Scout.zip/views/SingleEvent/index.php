<?include(PATH.'templates/navHeader.php');?>
<div class=" text-center">
</div>
<div class="container">
	<div class="item active">
		<img src="<?=assets('img/portfolio/wide-port1.jpg')?>" alt="Los Angeles" style="width:100%;">
		<div class="carousel-caption">
			<h1 class="Ename">Event Name</h1>
			<a href="#" title="Attend"><i class="fa fa-star-o fa-4x" aria-hidden="true"></i></a><br>
			<span>Small Simple Tittle </span>

		</div>
	</div>
	<a href="#editForm" id="edit" data-toggle="modal"><i class="fa fa-cogs fa-lg" aria-hidden="true"></i></a>
</div>
<div class="entry wow fadeInDown " data-wow-duration="1000ms" data-wow-delay="300ms">

	<div class="post-excerpt">
		<h2>Description</h2>
		<span>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Beatae modi quisquam laboriosam, expedita ea natus tempora unde sed sequi velit, quia veniam libero quos sunt praesentium nisi odit architecto fugiat? Lorem ipsum dolor sit amet, consectetur adipisicing elit. Beatae modi quisquam laboriosam, expedita ea natus tempora unde sed sequi velit, quia veniam libero quos sunt praesentium nisi odit architecto fugiat?</span>
	</div>
</div>
<br><br>
<div id="blog-posts" class="col-md-8 col-sm-8">
	<div class="post-item">

		<article class="entry wow fadeInDown" data-wow-duration="1000ms" data-wow-delay="300ms">


				<div class="post-thumb">
					<a href="single-post.html">
					<img src="img/blog/3D-beach-art.jpg" alt="3D Beach Art | Meghna" class="img-responsive">
					</a>
				


				</div>
				<div class="post-excerpt">
					<h3><a href="#">Siple Post</a></h3>
					<span>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Beatae modi quisquam laboriosam, expedita ea natus tempora unde sed sequi velit, quia veniam libero quos sunt praesentium nisi odit architecto fugiat? Lorem ipsum dolor sit amet, consectetur adipisicing elit. Beatae modi quisquam laboriosam, expedita ea natus tempora unde sed sequi velit, quia veniam libero quos sunt praesentium nisi odit architecto fugiat?</span>
				</div>
				<div class="post-meta">
					<span class="post-date">
					<i class="fa fa-calendar"></i>30 jun 2014 <!--Variables-->
				</span>
				


					<span class="comments">
					<i class="fa fa-comments"></i>18 Comments
				</span>
				


					<span class="post-view">
					<i class="fa fa-eye"></i>265 Views
				</span>
				


					<span class="author">
					<i class="fa fa-user"></i><a href="#">Admin/User</a><!--If the admin who post this post-->
				</span>
				


				</div>
			</article>
		</div>
	</div>
	<div id="right-sidebar" class="col-md-4 col-sm-4">
		<!-- Single post -->
		<section id="blog-page">
			<div class="container">
				<div class="row">
					<!--Single Event-->
					<!-- Widget Section -->
					<div id="right-sidebar" class="col-md-4 col-sm-4">
						<!--=====================Control aside====================================-->
						<!-- Single Widget -->
						<aside class="widget wow fadeInUp">
							<div class="widget-title">
								<h3>Tab	 Widget</h3>
							</div>

							<div class="widget-content">
								<!-- tab nav -->
								<ul class="tab-post-nav clearfix">
									<li class="active"><a href="#popular" data-toggle="tab">Popular Post</a>
									</li>
									<li><a href="#recent" data-toggle="tab">Recent Post</a>
									</li>
									<li><a href="#most-viewed" data-toggle="tab">Most Viewed</a>
									</li>
								</ul>
								<!-- /tab nav -->

								<!-- tab content -->
								<div class="tab-content">
									<article class="tab-pane active tab-post" id="popular">
										<div class="clearfix">
											<div class="tab-thumb">
												<img src="img/blog/3D-beach-art.jpg" class="img-responsive" alt="3D Beach Art | Meghna">
											</div>
											<div class="tab-excerpt">
												<h4><a href="single.html">Post Title Demo</a></h4>
												<span>November 15 2014</span>
												<span>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Inventore, laboriosam molestiae aliquam rem enim earum eos suscipit! Dolore, molestiae, quidem quo quam deleniti ullam dicta. Incidunt, quaerat est deserunt voluptatum.</span>
											</div>
										</div>
										<div class="clearfix">
											<div class="tab-thumb">
												<img src="img/blog/amazing-caves-coverimage.jpg" class="img-responsive" alt="amazing-caves-coverimage | Meghna">
											</div>
											<div class="tab-excerpt">
												<h4><a href="single.html">Post Title Demo</a></h4>
												<span>November 15 2014</span>
												<span>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Inventore, laboriosam molestiae aliquam rem enim earum eos suscipit! Dolore, molestiae, quidem quo quam deleniti ullam dicta. Incidunt, quaerat est deserunt voluptatum.</span>
											</div>
										</div>
									</article>

									<article class="tab-pane tab-post" id="recent">
										<div class="clearfix">
											<div class="tab-thumb">
												<img src="img/blog/amazing-caves-coverimage.jpg" class="img-responsive" alt="amazing-caves-coverimage | Meghna">
											</div>
											<div class="tab-excerpt">
												<h4><a href="single.html">Post Title Demo</a></h4>
												<span>November 15 2014</span>
												<span>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Inventore, laboriosam molestiae aliquam rem enim earum eos suscipit! Dolore, molestiae, quidem quo quam deleniti ullam dicta. Incidunt, quaerat est deserunt voluptatum.</span>
											</div>
										</div>
										<div class="clearfix">
											<div class="tab-thumb">
												<img src="img/blog/3D-beach-art.jpg" class="img-responsive" alt="3D Beach Art | Meghna">
											</div>
											<div class="tab-excerpt">
												<h4><a href="single.html">Post Title Demo</a></h4>
												<span>November 15 2014</span>
												<span>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Inventore, laboriosam molestiae aliquam rem enim earum eos suscipit! Dolore, molestiae, quidem quo quam deleniti ullam dicta. Incidunt, quaerat est deserunt voluptatum.</span>
											</div>
										</div>
									</article>

									<article class="tab-pane tab-post" id="most-viewed">
										<div class="clearfix">
											<div class="tab-thumb">
												<img src="img/blog/bicycle.jpg" class="img-responsive" alt="bicycle | Meghna">
											</div>
											<div class="tab-excerpt">
												<h4><a href="single.html">Post Title Demo</a></h4>
												<span>November 15 2014</span>
												<span>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Inventore, laboriosam molestiae aliquam rem enim earum eos suscipit! Dolore, molestiae, quidem quo quam deleniti ullam dicta. Incidunt, quaerat est deserunt voluptatum.</span>
											</div>
										</div>
										<div class="clearfix">
											<div class="tab-thumb">
												<img src="img/blog/3D-beach-art.jpg" class="img-responsive" alt="3D Beach Art | Meghna">
											</div>
											<div class="tab-excerpt">
												<h4><a href="single.html">Post Title Demo</a></h4>
												<span>November 15 2014</span>
												<span>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Inventore, laboriosam molestiae aliquam rem enim earum eos suscipit! Dolore, molestiae, quidem quo quam deleniti ullam dicta. Incidunt, quaerat est deserunt voluptatum.</span>
											</div>
										</div>
									</article>

								</div>
								<!-- /tab content -->
							</div>
						</aside>
						<!-- End Single Widget -->
						<!-- Single Widget -->
						<aside class="widget wow fadeInDown">
							<div class="widget-title">
								<h3>Newsletter</h3>
								<span>Signup to receive email updates and to hear what's going on with my blog!</span>
							</div>
							<div class="widget-content">
								<form action="">
									<input type="email" name="email" class="form-control" placeholder="Enter your email" required="">
									<input type="submit" value="Subscribe" class="btn btn-transparent">
								</form>
							</div>
						</aside>
						<!-- End Single Widget -->
					</div>
					<!-- End Widget Section -->

			<div class="post-thumb">
				<a href="single-post.html">
			<img src="img/blog/3D-beach-art.jpg" alt="3D Beach Art | Meghna" class="img-responsive">
		</a>
			


			</div>
			<div class="post-excerpt">
				<h3><a href="#">Siple Post</a></h3>
				<span>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Beatae modi quisquam laboriosam, expedita ea natus tempora unde sed sequi velit, quia veniam libero quos sunt praesentium nisi odit architecto fugiat? Lorem ipsum dolor sit amet, consectetur adipisicing elit. Beatae modi quisquam laboriosam, expedita ea natus tempora unde sed sequi velit, quia veniam libero quos sunt praesentium nisi odit architecto fugiat?</span>
			</div>
			<div class="post-meta">
				<span class="post-date">
			<i class="fa fa-calendar"></i>30 jun 2014 <!--Variables-->
		</span>
			


				<span class="comments">
			<i class="fa fa-comments"></i>18 Comments
		</span>
			


				<span class="post-view">
			<i class="fa fa-eye"></i>265 Views
		</span>
			


				<span class="author">
			<i class="fa fa-user"></i><a href="#">Admin/User</a><!--If the admin who post this post-->
		</span>
			



			</div>
		</article>
	</div>
</div>
<!-- Edit Modal -->
<div id="editForm" class="modal fade" role="dialog">
	<div class="modal-dialog">

		<!-- Modal content-->
		<div class="modal-content">
			<div class="modal-header">
				<h4 class="modal-title">Edit Event!</h4>
			</div>
			<div class="modal-body">
				<div id="eventedit">
					<div id="view">
						<img id="ImgReview"/>
					</div>
					<form action="">
						<div class="form-group">
							<label for="eventName">Change Event Name :</label>
							<input type="text" class="form-control" id="eventName" required>
						</div>
						<div class="form-group">
							<label for="eventName">Change Event tag :</label>
							<input type="text" class="form-control" id="eventName">
						</div>
						<div class="form-group">
							<label for="Description">Change Dexcription :</label>
							<textarea id="description" name="Text1" cols="70" rows="2"></textarea>
						</div>
						<div class="form-group">
							<label for="eventName">Change Event Image :</label>
							<input id="eventmage" type="file" accept="image/jpeg" style="width:200px;" name="eventImg" required>
						</div>
						<div class="form-group">
							<div id="sub">
								<input style="border-radius: 20px; width: 56%;" type="submit" class="btn btn-success"/>
							</div>
						</div>
					</form>
				</div>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-danger" style="border-radius: 20px;" data-dismiss="modal">Close</button>
			</div>
		</div>

	</div>

<div id="right-sidebar" class="col-md-4 col-sm-4">
	<!-- Single Widget -->
	<aside class="widget wow fadeInDown">
		<div class="widget-title">
			<h3>Text FeedBack</h3>
		</div>
		<div class="widget-content">
			<span>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Doloribus ducimus in dolorum accusantium voluptate nostrum, excepturi dolores voluptatem vel rerum at, recusandae inventore nobis ex eveniet sunt eligendi, qui provident.</span>
		</div>
	</aside>



</div>
<?include(PATH.'templates/footer.php');?>