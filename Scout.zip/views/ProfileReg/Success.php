<?include(PATH."templates/header.php")?>

<div class="alert alert-success">Congreatulation !!</div>
<?include(PATH."templates/footer.php")?>
