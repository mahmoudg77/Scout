<?include(PATH.'templates/header.php');?>

<center>
    <h1>Welcome to  <?=$Website?></h1>
    <h1>Date <?=$Date?></h1> 
</center>

<?include(PATH.'templates/footer.php');?>
