<?
namespace App\Controllers;

class ContactUser extends BaseController
{
    protected  $model="App\Models\Profile\ContactUser";
    protected $authRequired=true;

}

?>
