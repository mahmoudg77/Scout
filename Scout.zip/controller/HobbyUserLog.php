<?
namespace App\Controllers;

class HobbyUserLog extends BaseController
{
    protected  $model="App\Models\Profile\HobbyUserLog";
    protected $authRequired=true;

}

?>
