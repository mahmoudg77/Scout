<?
namespace App\Controllers;

class PositionUserLog extends BaseController
{
    protected  $model="App\Models\Profile\PositionUserLog";
    protected $authRequired=true;

}

?>
