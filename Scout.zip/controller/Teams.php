<?
namespace App\Controllers;

class Teams extends BaseController
{
    protected  $model="App\Models\Admin\Teams";
    protected $authRequired=true;


}

?>
