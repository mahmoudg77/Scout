<?
namespace App\Controllers;
class Position extends BaseController
{
    protected  $model="App\Models\Lookup\Position";
    protected $authRequired=true;


}

?>
