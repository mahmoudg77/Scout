<?
namespace App\Controllers;

class Hobbies extends BaseController
{
    protected  $model="App\Models\Lookup\Hobbies";
    protected $authRequired=true;

}

?>
