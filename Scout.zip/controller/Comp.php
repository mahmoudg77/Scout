<?
namespace App\Controllers;

class Comp extends BaseController
{
    protected  $model="App\Models\Profile\Comp";
    protected $authRequired=true;


}

?>
