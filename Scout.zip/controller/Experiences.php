<?
namespace App\Controllers;

class Experiences extends BaseController
{
    protected  $model="App\Models\Lookup\Experiences";
    protected $authRequired=true;

}

?>
