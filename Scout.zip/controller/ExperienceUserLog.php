<?
namespace App\Controllers;

class ExperienceUserLog extends BaseController
{
    protected  $model="App\Models\Profile\ExperienceUserLog";
    protected $authRequired=true;

}

?>
