﻿ALTER TABLE `users` ADD `api_tokrn` VARCHAR(100) NULL AFTER `token`;
