<?
namespace App\Models\Content;

use Framework\Database;
use Framework\BLL;

class SinglePost extends BLL{
	var $tablename="posts";
	var $col_pk="id";

	var $fields=[

	    ];
}
?>
