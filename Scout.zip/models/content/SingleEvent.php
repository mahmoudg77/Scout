<?
namespace App\Models\Content;

use Framework\Database;
use Framework\BLL;

class SingleEvent extends BLL{
	var $tablename="events";
	var $col_pk="id";

	var $fields=[

	    ];
}
?>
