<?
namespace App\Models\Admin;

use Framework\Database;
use Framework\BLL;

class Register extends BLL{
	var $tablename="register";
	var $col_pk="id";

	var $fields=[

  	    ];

    function name(){
        return $this->regYear;
    }
}
?>
