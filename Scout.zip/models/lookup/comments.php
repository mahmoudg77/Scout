<?
namespace App\Models\Lookup;

use Framework\Database;
use Framework\BLL;

class comments extends BLL{
	var $tablename="comments";
	var $col_pk="id";

	var $fields=[

	    ];
}
?>
