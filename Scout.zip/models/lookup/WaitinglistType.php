<?
namespace App\Models\Lookup;

use Framework\Database;
use Framework\BLL;

class WaitinglistType extends BLL{
	var $tablename="waitinglisttype";
	var $col_pk="id";

	var $fields=[

	    ];
}
?>
