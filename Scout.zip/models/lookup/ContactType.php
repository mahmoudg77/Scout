<?
namespace App\Models\Lookup;

use Framework\Database;
use Framework\BLL;

class ContactType extends BLL{
	var $tablename="contacttype";
	var $col_pk="id";

	var $fields=[
	    ];

	
}
?>
