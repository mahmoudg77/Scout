<?
namespace App\Models\Lookup;

use Framework\Database;
use Framework\BLL;

class Studies extends BLL{
	var $tablename="studies";
	var $col_pk="id";

	var $fields=[

	    ];
}
?>
