<?
namespace App\Models\Lookup;

use Framework\Database;
use Framework\BLL;

class Experiences extends BLL{
	var $tablename="experiences";
	var $col_pk="id";

	var $fields=[

	    ];
}
?>
