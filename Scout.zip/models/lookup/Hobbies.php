<?
namespace App\Models\Lookup;

use Framework\Database;
use Framework\BLL;

class Hobbies extends BLL{
	var $tablename="hobbies";
	var $col_pk="id";

	var $fields=[

	    ];
}
?>
