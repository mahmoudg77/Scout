<?if(!$request->isAjax())include(PATH.'templates/cpheader.php');?>

 
<?if(!$request->isAjax())include(PATH.'templates/cpfooter.php');?>
