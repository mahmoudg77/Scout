<?
namespace App\Models\Admin;

use Framework\Database;
use Framework\BLL;

class TeamRegView extends BLL{
	var $tablename="teaminfo";
	var $col_pk="id";

	var $fields=[];


}
?>
