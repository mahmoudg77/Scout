<?
namespace App\Models\Lookup;

use Framework\Database;
use Framework\BLL;

class SingleEvent extends BLL{
	var $tablename="";
	var $col_pk="id";

	var $fields=[

	    ];
}
?>
