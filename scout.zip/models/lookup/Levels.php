<?
namespace App\Models\Lookup;

use Framework\Database;
use Framework\BLL;

class Levels extends BLL{
	var $tablename="level";
	var $col_pk="id";

	var $fields=[

	    ];
}
?>
