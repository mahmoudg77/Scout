<?
namespace App\Controllers;

class ContactType extends BaseController
{
    protected  $model="App\Models\Lookup\ContactType";
    protected $authRequired=true;

}

?>
