<?
namespace App\Controllers;

class Images extends BaseController
{
    protected $model="App\Models\Media\Images";
    protected $authRequired=true;



}

?>
