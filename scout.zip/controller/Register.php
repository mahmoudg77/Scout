<?
namespace App\Controllers;

class Register extends BaseController
{
    protected  $model="App\Models\Admin\Register";
    protected $authRequired=true;

}

?>
