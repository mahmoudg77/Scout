<?
namespace App\Controllers;

class Studies extends BaseController
{
    protected  $model="App\Models\Lookup\Studies";
    protected $authRequired=true;

}

?>
