<?
namespace App\Controllers;

class RegisteryUserLog extends BaseController
{
    protected  $model="App\Models\Admin\RegisteryUserLog";
    protected $authRequired=true;

}

?>
