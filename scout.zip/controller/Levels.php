<?
namespace App\Controllers;

class Levels extends BaseController
{
    protected  $model="App\Models\Lookup\Levels";
    protected $authRequired=true;

}

?>
