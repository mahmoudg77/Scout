<?
namespace App\Controllers;

class CompUserLog extends BaseController
{
    protected  $model="App\Models\Profile\CompUserLog";
    protected $authRequired=true;

}

?>
