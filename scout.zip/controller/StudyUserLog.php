<?
namespace App\Controllers;

class StudyUserLog extends BaseController
{
    protected  $model="App\Models\Profile\StudyUserLog";
    protected $authRequired=true;

}

?>
